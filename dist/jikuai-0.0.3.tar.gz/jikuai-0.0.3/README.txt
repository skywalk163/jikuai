# jikuai Package

This is a simple tools package for AI. 
0.01版本实现AI训练的第一步，数据集划分。